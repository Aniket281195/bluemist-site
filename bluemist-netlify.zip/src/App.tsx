import React from 'react'
import ContactForm from './components/ContactForm'

export default function App() {
  return (
    <div style={{background:'#111', minHeight:'100vh', color:'#fff'}}>
      <ContactForm />
    </div>
  )
}